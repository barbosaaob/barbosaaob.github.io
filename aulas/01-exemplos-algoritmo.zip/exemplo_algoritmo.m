%
% calcula a soma dos n primeiros numeros naturais
%

% entrada
n = 100;

% inicializacao
soma = 0;

% calculo da soma
for numero = 1:n
    soma = soma + numero;
end

% exibe a soma na tela
disp(soma);
