%
% soma uma lista de numeros
%

% entrada
numeros = [1, 5, 7, 9, 2, 13, 32, 23, 100];

% inicializacao
soma = 0;

% calculo da soma
for i = 1:length(numeros)
    soma = soma + numeros(i);
end

% exibe a soma na tela
disp(soma);
