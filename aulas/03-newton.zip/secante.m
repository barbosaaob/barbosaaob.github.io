% entrada
p0 = -1.1;         % aproximacao inicial
p1 = 1.5;          % segunda aproximacao inicial
tol = 1e-5;        % tolerancia
N = 50;            % maximo de iteracoes
f = @(x) sin(x);   % funcao

% inicializacao
saida = 1;

% calculando
i = 2;
q0 = f(p0);
q1 = f(p1);
while (i <= N)
    p = p1 - ( q1 * (p1 - p0) / (q1 - q0) );
    if abs(p - p1) < tol
        disp(p);
        saida = 0;
        break;
    end
    i = i + 1;
    p0 = p1;
    q0 = q1;
    p1 = p;
    q1 = f(p);
end

if (saida == 1)
    disp('Numero maximo de iteracoes alcancado.');
end
