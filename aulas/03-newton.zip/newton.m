% entrada
p0 = -1.1;         % aproximacao inicial
tol = 1e-5;        % tolerancia
N = 50;            % maximo de iteracoes
f = @(x) sin(x);   % funcao
df = @(x) cos(x);  % derivada de f

% inicializacao
saida = 1;

% calculando
i = 1;
while (i <= N)
    p = p0 - (f(p0) / df(p0));
    if abs(p - p0) < tol
        disp(p);
        saida = 0;
        break;
    end
    i = i + 1;
    p0 = p;
end

if (saida == 1)
    disp('Numero maximo de iteracoes alcancado.');
end
