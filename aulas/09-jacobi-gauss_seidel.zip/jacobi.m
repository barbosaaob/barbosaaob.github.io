function x = jacobi(A, b, x0, tol, num_it)
% entrada: matriz A, vetor b, sol inicial x0 e tolerancia
switch nargin
    case 3
        tol = 1e-5;
        num_it = 1000;
    case 4
        num_it = 1000;
    otherwise
        disp('parametros insuficientes');
        x = NaN;
        return;
end
zero_tol = 1e-10;
n = size(A, 1);

% saida
x = zeros(size(x0));

% calculando
k = 1;
while (k <= num_it)
    for i = 1:n
        if (abs(A(i, i)) < zero_tol)
            disp('sistema singular! pivotamento nao implementado...')
            x = NaN;
            return;
        end
        s = 0;
        for j = 1:n
            if (j != i)
                s = s + A(i, j)*x0(j);
            end
        end
        x(i) = (-s + b(i)) / A(i, i);
    end
    erro = norm(x-x0, inf) / norm(x, inf);
    if (erro < tol)
        disp(['convergiu em ', num2str(k), ' iteracoes.']);
        disp(['erro: ', num2str(erro)]);
        return;
    end
    k = k + 1;
    x0 = x;
end
disp('numero maximo de iteracoes alcancado.')
x = NaN;
return;
