% entrada
f = @(x) exp(x) - 3 * x^2;  % funcao
a = 3;       % inicio do intervalo
b = 4;       % fim do intervalo
tol = 1e-5;  % tolerancia
N = 1e5;     % maximo de iteracoes

% inicializacao
saida = 1;

% calculo
i = 1;
fa = f(a);

while (i <= N)
    p = (a + b) / 2;
    fp = f(p);
    if ( (fp == 0) || ((b-a)/2 < tol) )
        disp(p);
        saida = 0;
        break;
    end
    if (fa * fp > 0)
        a = p;
        fa = fp;
    else
        b = p;
    end
    i = i + 1;
end

if (saida == 1)
    disp('Numero maximo de iteracoes alcancado.');
end
